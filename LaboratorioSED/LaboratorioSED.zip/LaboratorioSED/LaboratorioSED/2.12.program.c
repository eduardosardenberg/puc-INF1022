int main(void){
    int x,y,z;
    float a,b,c;
    return 1;
}